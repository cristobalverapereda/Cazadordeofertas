# 🎯 Cazador de Ofertas para Android — Proyecto fuente

**Esta carpeta NO es un APK ya compilado.** Es un proyecto Android en Java listo para generar `app-debug.apk` usando Android Studio o GitHub Actions. No es necesario mantener un servidor Python/Streamlit encendido para consultar y almacenar tus encargos en el teléfono.

## Funciones implementadas

- Interfaz móvil privada, instalada como aplicación Android real (WebView local, no una página alojada en Internet).
- Agregar, modificar, pausar y eliminar encargos de productos; ejemplo precargado de camisetas Star Wars tipo jersey.
- Precio máximo en USD, exclusiones de búsqueda, frecuencia aproximada de 6 a 72 horas.
- Buscar manualmente por Google Shopping Chile y por tiendas indexadas (AliExpress, Temu, Banggood, DHgate y Shein).
- Mostrar ofertas con precio **publicado**, comercio y enlace; ordenar por precio en USD cuando la moneda puede identificarse.
- Guardar historial de 20 comprobaciones y hasta 75 ofertas por encargo en el teléfono; mostrar mejor precio histórico.
- Revisiones automáticas mediante `JobScheduler` de Android y notificación local cuando aparezca un **nuevo mínimo** igual o inferior al objetivo.
- Clave de SerpApi ingresada por el usuario, guardada en `SharedPreferences` privados de la aplicación; no integrada en la compilación.

## Lo que NO hace

- No busca automáticamente por similitud de imagen: debes describir el producto, idealmente en inglés.
- No usa la API oficial de AliExpress ni consulta cada ficha de producto; depende de lo que Google y SerpApi indexen.
- No conoce el total final pagado en Chile: envío, IVA, aduanas y variantes pueden cambiar el precio.
- No compra automáticamente y no garantiza encontrar el precio mínimo absoluto de Internet.
- No monitoriza 24/7 de manera garantizada: Android puede retrasar las tareas en segundo plano, especialmente con ahorro de batería o si se fuerza el cierre de la aplicación.
- No incluye un servidor central, alertas Telegram ni sincronización entre teléfonos; las alertas son notificaciones locales de Android.

## Compilar con Android Studio (Windows/macOS/Linux)

1. Instala Android Studio de [developer.android.com/studio](https://developer.android.com/studio).
2. Descomprime esta carpeta. En Android Studio usa **Open** y selecciona la carpeta que contiene `settings.gradle`.
3. Instala el Android SDK Platform 35 cuando Android Studio lo solicite. Necesitarás conexión a Internet para descargar Gradle y herramientas de Android.
4. Selecciona **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. El archivo generado estará en `app/build/outputs/apk/debug/app-debug.apk`.
6. Copia ese `.apk` a tu Android, ábrelo y autoriza la instalación desde esa fuente si el sistema lo solicita.

## Compilar sin instalar Android Studio, desde GitHub

Se incluye `.github/workflows/build-apk.yml`. Crea un repositorio **privado** en GitHub y sube el contenido de esta carpeta. En la pestaña **Actions**, selecciona **Compilar APK Android**, pulsa **Run workflow** y descarga el artefacto **CazadorDeOfertas-APK** de la ejecución. Dentro encontrarás `app-debug.apk`.

*Requiere cuenta GitHub; sus cuotas y disponibilidad dependen de GitHub. El workflow utiliza Gradle y Android SDK oficiales. El archivo generado usa una firma de depuración y es apto para instalar manualmente, pero no para publicar en Google Play. No almacenes tu API key en GitHub.*

## Activar búsquedas y alertas

1. Abre el APK en tu Android y concede permiso para mostrar notificaciones cuando lo solicite.
2. Registra una clave de SerpApi en [serpapi.com](https://serpapi.com/) y en **⚙ Ajustes** guárdala. Las búsquedas usan tu cuota de SerpApi.
3. Edita el ejemplo o crea un encargo: «Star Wars v neck sports jersey shirt», máximo US$5, tiendas AliExpress/Temu.
4. Presiona **Buscar**. La app consultará la búsqueda en una tarea de red fuera de la interfaz, mostrará resultados y guardará el historial.
5. Deja el encargo activo para que Android programe las revisiones periódicas. La frecuencia configurada es aproximada y **Android puede diferir las ejecuciones**; no depende de que permanezcas con la pantalla abierta, pero sí de que el sistema permita las tareas programadas.

## Tecnología

- `app/src/main/java/`: actividad Android, almacenamiento, búsqueda y tareas en segundo plano.
- `app/src/main/assets/index.html`: interfaz HTML/CSS/JavaScript incluida dentro del APK.
- Android `minSdk 26`, `targetSdk 35`, Java 17, Android Gradle Plugin 8.7.3.
- Solo bibliotecas incluidas en Android. Sin librerías externas de tiempo de ejecución.
- Acceso HTTPS a `serpapi.com` y `open.er-api.com` (tipo de cambio).

## Estado de validación

El código fuente y el JavaScript de la interfaz se verificaron localmente mediante comprobaciones estáticas. La compilación Android y la instalación en un dispositivo **todavía no pudieron verificarse** en el entorno que generó estos archivos, porque allí no están disponibles el Android SDK, Gradle ni acceso de red para descargarlos. No afirmamos que exista un APK compilado en este paquete.
