package cl.cazadordeofertas;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Consulta resultados INDEXADOS. No scrapea AliExpress ni verifica el checkout. */
public final class SearchEngine {
    private static final String SERP="https://serpapi.com/search.json";
    private static final String CHANNEL="cazador_precio";
    private static final String[] DOMAINS={"aliexpress.com","temu.com","banggood.com","dhgate.com","shein.com"};
    private static final String[] NAMES={"AliExpress","Temu","Banggood","DHgate","Shein"};
    private static final Set<String> STOP=new HashSet<>(Arrays.asList("the","a","of","for","new","and","de","la","el","en","con","para","shirt","camiseta","tshirt","top","fashion","2026","unisex"));
    private SearchEngine() {}

    private static String request(String url) throws Exception {
        HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();
        conn.setRequestMethod("GET"); conn.setConnectTimeout(12000); conn.setReadTimeout(28000);
        conn.setRequestProperty("Accept","application/json");
        try {
            int code=conn.getResponseCode();
            InputStream in=(code>=200&&code<300)?conn.getInputStream():conn.getErrorStream();
            if(in==null) throw new Exception("Error HTTP "+code);
            StringBuilder str=new StringBuilder();
            try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))) {
                String line;
                while((line=r.readLine())!=null) {
                    str.append(line);
                    if(str.length()>10_000_000) throw new Exception("Respuesta demasiado grande");
                }
            }
            if(code<200 || code>=300) {
                JSONObject error;
                try { error=new JSONObject(str.toString()); }
                catch(Exception ignored) { throw new Exception("Error HTTP "+code); }
                throw new Exception(error.optString("error","Error HTTP "+code));
            }
            return str.toString();
        } finally { conn.disconnect(); }
    }

    private static String enc(String s) { try { return URLEncoder.encode(s,"UTF-8"); } catch(java.io.UnsupportedEncodingException e) { throw new IllegalStateException(e); } }
    private static JSONObject serp(String apiKey,String engine,String query) throws Exception {
        String url=SERP+"?engine="+enc(engine)+"&q="+enc(query)+"&gl=cl&hl=es&location="+enc("Santiago,Chile")+"&api_key="+enc(apiKey);
        JSONObject obj=new JSONObject(request(url));
        if(obj.has("error")) throw new Exception(obj.optString("error"));
        return obj;
    }

    private static double rate() {
        try {
            JSONObject data=new JSONObject(request("https://open.er-api.com/v6/latest/USD"));
            return data.getJSONObject("rates").getDouble("CLP");
        } catch(Exception e) { return 0; }
    }

    private static String clean(String s) {
        String text=Normalizer.normalize(s.toLowerCase(Locale.ROOT),Normalizer.Form.NFD).replaceAll("\\p{M}","");
        return text.replaceAll("[^a-z0-9 ]"," ").replaceAll(" +"," ").trim();
    }
    private static double similarity(String query,String title) {
        Set<String> q=new HashSet<>(),t=new HashSet<>(Arrays.asList(clean(title).split(" ")));
        for(String tok:clean(query).split(" ")) if(tok.length()>1&&!STOP.contains(tok)) q.add(tok);
        if(q.isEmpty()) return 0;
        int overlap=0; for(String tok:q) if(t.contains(tok)) overlap++;
        return (double)overlap/q.size();
    }

    private static String merchant(String url,String source) {
        String all=(url+" "+source).toLowerCase(Locale.ROOT);
        for(int i=0;i<DOMAINS.length;i++) if(all.contains(DOMAINS[i]) || all.contains(NAMES[i].toLowerCase(Locale.ROOT))) return NAMES[i];
        if(!source.trim().isEmpty()) return source.trim();
        try { return new URL(url).getHost(); }
        catch(Exception e) { return "Otra tienda"; }
    }

    private static boolean allows(JSONObject w,String store) {
        String selected=","+w.optString("stores", "AliExpress,Temu").toLowerCase(Locale.ROOT).replace(" ","")+",";
        if(selected.contains(","+store.toLowerCase(Locale.ROOT).replace(" ","")+",")) return true;
        for(String s:NAMES) if(s.equalsIgnoreCase(store)) return false;
        return true; // Tienda alternativa en Google Shopping
    }

    /** Retorna precio y moneda. No se fuerza conversión si no sabemos la moneda. */
    static Price parsePrice(String raw) {
        if(raw==null) return null;
        String s=raw.toUpperCase(Locale.ROOT);
        String currency=null;
        if(s.contains("USD") || s.contains("US$") || s.contains("US $")) currency="USD";
        else if(s.contains("CLP") || s.contains("CL$") || s.contains("CL $")) currency="CLP";
        else if(s.contains("$")) currency="CLP";
        else return null;
        Matcher m=Pattern.compile("(?:USD|CLP|US\\s*\\$|CL\\s*\\$|\\$)\\s*([0-9][0-9.,]*)",Pattern.CASE_INSENSITIVE).matcher(s);
        if(!m.find()) return null;
        String n=m.group(1);
        if(n.endsWith(".")||n.endsWith(",")) n=n.substring(0,n.length()-1);
        if(n.isEmpty()) return null;
        if(currency.equals("CLP") && n.matches("\\d{1,2}\\.\\d{2}")) currency="USD";
        if(n.contains(".")&&n.contains(",")) {
            if(n.lastIndexOf(',')>n.lastIndexOf('.')) n=n.replace(".","").replace(",",".");
            else n=n.replace(",","");
        } else if(n.contains(",")) {
            String suffix=n.substring(n.lastIndexOf(',')+1);
            n=suffix.length()==3?n.replace(",",""):n.replace(",",".");
        } else if(n.contains(".")) {
            String suffix=n.substring(n.lastIndexOf('.')+1);
            if(suffix.length()==3) n=n.replace(".","");
        }
        try { double v=Double.parseDouble(n); return v>0?new Price(v,currency):null; }
        catch(NumberFormatException e) { return null; }
    }
    static final class Price {
        final double value; final String currency;
        Price(double value,String currency) { this.value=value; this.currency=currency; }
    }

    private static void collect(JSONArray array,JSONObject watch,double usdClp,Map<String,JSONObject> offers) {
        if(array==null) return;
        String query=watch.optString("query");
        String exclusion=watch.optString("exclude");
        for(int i=0;i<array.length();i++) {
            JSONObject source=array.optJSONObject(i); if(source==null) continue;
            try {
                String title=source.optString("title","").trim();
                String link=source.optString("link",source.optString("product_link",""));
                if(title.isEmpty() || !(link.startsWith("https://")||link.startsWith("http://"))) continue;
                String normalized=clean(title);
                boolean excluded=false;
                for(String term:exclusion.split("[,;]")) if(!term.trim().isEmpty() && normalized.contains(clean(term.trim()))) { excluded=true; break; }
                if(excluded) continue;
                double score=similarity(query,title); if(score<0.5) continue;
                String shop=merchant(link,source.optString("source",""));
                if(!allows(watch,shop)) continue;
                String priceLabel=source.optString("price","");
                if(priceLabel.isEmpty()) priceLabel=source.optString("snippet","");
                Price price=parsePrice(priceLabel);
                if(price==null) continue;
                double usd=price.currency.equals("USD")?price.value:usdClp>0?price.value/usdClp:Double.NaN;
                if(Double.isNaN(usd)||Double.isInfinite(usd)) continue;
                // Debe tratarse del precio indexado, no una estimación de envío ni garantía de talla.
                JSONObject offer=new JSONObject();
                offer.put("title",title); offer.put("url",link);
                offer.put("shop",shop); offer.put("currency",price.currency);
                offer.put("price",price.value); offer.put("priceLabel",priceLabel.substring(0,Math.min(90,priceLabel.length())));
                offer.put("usd",Math.round(usd*100.0)/100.0); offer.put("score",score);
                offer.put("image",source.optString("thumbnail",""));
                JSONObject previous=offers.get(link);
                if(previous==null || previous.optDouble("usd",Double.MAX_VALUE)>offer.optDouble("usd")) offers.put(link,offer);
            } catch(Exception ignored) { /* resultado no procesable */ }
        }
    }

    public static JSONObject scan(Context context,int id) throws Exception {
        if(Store.apiKey(context).isEmpty()) throw new Exception("Configura tu clave de SerpApi en Ajustes.");
        JSONObject watch=Store.get(context,id);
        if(watch==null) throw new Exception("No se encontró el encargo.");
        String key=Store.apiKey(context);
        double usdClp=rate();
        Map<String,JSONObject> found=new HashMap<>();
        JSONArray errors=new JSONArray(); int searches=0;
        try {
            JSONObject data=serp(key,"google_shopping",watch.optString("query")); searches++;
            collect(data.optJSONArray("shopping_results"),watch,usdClp,found);
        } catch(Exception e) { errors.put("Google Shopping: "+e.getMessage()); }
        StringBuilder sites=new StringBuilder();
        String selected=watch.optString("stores","");
        for(int i=0;i<NAMES.length;i++) if(selected.toLowerCase(Locale.ROOT).contains(NAMES[i].toLowerCase(Locale.ROOT))) {
            if(sites.length()>0) sites.append(" OR ");
            sites.append("site:").append(DOMAINS[i]);
        }
        if(sites.length()>0) {
            try {
                JSONObject data=serp(key,"google",watch.optString("query")+" ("+sites+")"); searches++;
                collect(data.optJSONArray("organic_results"),watch,usdClp,found);
            } catch(Exception e) { errors.put("Índice de tiendas: "+e.getMessage()); }
        }
        if(found.isEmpty()&&errors.length()>0) throw new Exception(errors.optString(0,"No se pudo buscar"));
        ArrayList<JSONObject> list=new ArrayList<>(found.values());
        Collections.sort(list,Comparator.comparingDouble(o->o.optDouble("usd",Double.MAX_VALUE)));
        JSONArray results=new JSONArray(); for(int i=0;i<Math.min(list.size(),75);i++) results.put(list.get(i));
        double best=list.isEmpty()?Double.NaN:list.get(0).optDouble("usd",Double.NaN);
        JSONObject latest=Store.get(context,id); if(latest==null) latest=watch;
        long now=System.currentTimeMillis();
        latest.put("lastChecked",now); latest.put("offers",results);
        if(!Double.isNaN(best)) {
            double previous=latest.isNull("bestEver")?Double.MAX_VALUE:latest.optDouble("bestEver",Double.MAX_VALUE);
            if(best<previous) latest.put("bestEver",best);
        }
        JSONArray history=latest.optJSONArray("history"); if(history==null) history=new JSONArray();
        JSONArray updated=new JSONArray();
        JSONObject snapshot=new JSONObject();
        snapshot.put("timestamp",now); snapshot.put("count",results.length());
        snapshot.put("best",Double.isNaN(best)?JSONObject.NULL:best); snapshot.put("searches",searches);
        updated.put(snapshot);
        for(int i=0;i<Math.min(history.length(),19);i++) updated.put(history.get(i));
        latest.put("history",updated); Store.replace(context,latest);
        if(!Double.isNaN(best) && best<=latest.optDouble("maxUsd",0)) {
            double previousAlert=latest.isNull("lastAlert")?Double.MAX_VALUE:latest.optDouble("lastAlert",Double.MAX_VALUE);
            if(best<previousAlert-0.005) {
                if(notifyOffer(context,latest,list.get(0))) {
                    latest.put("lastAlert",best); Store.replace(context,latest);
                }
            }
        }
        JSONObject response=new JSONObject();
        response.put("watchId",id); response.put("count",results.length());
        response.put("best",Double.isNaN(best)?JSONObject.NULL:best);
        response.put("errors",errors); response.put("searches",searches);
        response.put("rateAvailable",usdClp>0);
        return response;
    }

    private static boolean notifyOffer(Context context,JSONObject watch,JSONObject offer) {
        NotificationManager m=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(m==null) return false;
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return false;
        NotificationChannel channel=new NotificationChannel(CHANNEL,"Ofertas encontradas",NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("Avisos de productos por debajo del precio indicado");
        m.createNotificationChannel(channel);
        String message=offer.optString("shop")+" · US$"+String.format(Locale.US,"%.2f",offer.optDouble("usd"))+" (publicado)";
        Notification notification=new Notification.Builder(context,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .setContentTitle("🎯 "+watch.optString("name"))
                .setContentText(message)
                .setStyle(new Notification.BigTextStyle().bigText(message+"\n"+offer.optString("title")+"\nConfirma envío e impuestos a Chile."))
                .setAutoCancel(true)
                .build();
        m.notify(watch.optInt("id"),notification);
        return true;
    }
}
