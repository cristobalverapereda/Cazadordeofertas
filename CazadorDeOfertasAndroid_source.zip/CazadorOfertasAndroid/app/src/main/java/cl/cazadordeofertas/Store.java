package cl.cazadordeofertas;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Datos privados de la aplicación. No sincroniza con servidores ajenos. */
public final class Store {
    private static final String PREF = "cazador_private";
    private Store() {}

    private static SharedPreferences p(Context c) { return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public static synchronized void seed(Context c) {
        if (p(c).getBoolean("seeded",false)) return;
        try {
            JSONArray a = new JSONArray();
            JSONObject w = new JSONObject();
            w.put("id",1); w.put("name","Poleras Star Wars tipo jersey");
            w.put("query","star wars v neck graphic sports jersey shirt");
            w.put("maxUsd",5.0); w.put("exclude","poster,sticker,figure");
            w.put("stores","AliExpress,Temu,Banggood,DHgate");
            w.put("frequency",24); w.put("active",true);
            w.put("lastChecked",0); w.put("bestEver",JSONObject.NULL);
            w.put("lastAlert",JSONObject.NULL); w.put("offers",new JSONArray());
            w.put("history",new JSONArray());
            a.put(w);
            p(c).edit().putString("watches",a.toString()).putBoolean("seeded",true).apply();
        } catch(JSONException e) { throw new IllegalStateException(e); }
    }

    public static synchronized JSONArray all(Context c) {
        seed(c);
        try { return new JSONArray(p(c).getString("watches","[]")); }
        catch(JSONException e) { return new JSONArray(); }
    }

    private static void write(Context c, JSONArray a) { p(c).edit().putString("watches",a.toString()).apply(); }

    public static synchronized JSONObject get(Context c,int id) {
        JSONArray a=all(c);
        for(int i=0;i<a.length();i++) {
            JSONObject w=a.optJSONObject(i);
            if(w!=null && w.optInt("id")==id) return w;
        }
        return null;
    }

    public static synchronized void save(Context c, JSONObject obj) throws JSONException {
        String name=obj.optString("name").trim(); String query=obj.optString("query").trim();
        double max=obj.optDouble("maxUsd",0);
        if(name.isEmpty() || query.isEmpty() || max<=0 || max>1000000) throw new JSONException("Completa nombre, búsqueda y un precio máximo válido.");
        JSONArray a=all(c); int id=obj.optInt("id");
        if(id<1) { id=p(c).getInt("nextId",2); p(c).edit().putInt("nextId",id+1).apply(); }
        JSONObject old=null; int index=-1;
        for(int i=0;i<a.length();i++) if(a.optJSONObject(i).optInt("id")==id) { old=a.optJSONObject(i); index=i; break; }
        JSONObject w= old==null ? new JSONObject() : new JSONObject(old.toString());
        w.put("id",id); w.put("name",name); w.put("query",query);
        w.put("maxUsd",max); w.put("exclude",obj.optString("exclude", ""));
        w.put("stores",obj.optString("stores", "AliExpress,Temu"));
        w.put("frequency",Math.max(6, Math.min(168,obj.optInt("frequency",24))));
        w.put("active",obj.optBoolean("active",true));
        if(old==null) { w.put("lastChecked",0); w.put("bestEver",JSONObject.NULL); w.put("lastAlert",JSONObject.NULL); w.put("offers",new JSONArray()); w.put("history",new JSONArray()); a.put(w); }
        else a.put(index,w);
        write(c,a);
    }

    public static synchronized void replace(Context c, JSONObject watch) throws JSONException {
        JSONArray a=all(c);
        for(int i=0;i<a.length();i++) if(a.optJSONObject(i).optInt("id")==watch.optInt("id")) { a.put(i,watch); write(c,a); return; }
    }

    public static synchronized void delete(Context c,int id) {
        JSONArray a=all(c), newArr=new JSONArray();
        for(int i=0;i<a.length();i++) if(a.optJSONObject(i).optInt("id")!=id) newArr.put(a.optJSONObject(i));
        write(c,newArr);
    }

    public static String apiKey(Context c) { return p(c).getString("serpKey","").trim(); }
    public static void apiKey(Context c,String key) { p(c).edit().putString("serpKey",key.trim()).apply(); }

    public static JSONObject state(Context c) {
        JSONObject s=new JSONObject();
        try { s.put("watches", all(c)); s.put("hasKey", !apiKey(c).isEmpty()); }
        catch(JSONException ignored) {}
        return s;
    }
}
