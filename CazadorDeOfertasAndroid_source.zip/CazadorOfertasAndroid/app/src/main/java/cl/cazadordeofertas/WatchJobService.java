package cl.cazadordeofertas;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

/** Android agrupa y puede retrasar las tareas periódicas por ahorro de batería. */
public class WatchJobService extends JobService {
    public static final int JOB_ID=228913;

    public static void schedule(Context context) {
        JobScheduler scheduler=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if(scheduler==null) return;
        if(Store.apiKey(context).isEmpty()) { scheduler.cancel(JOB_ID); return; }
        JobInfo job=new JobInfo.Builder(JOB_ID,new ComponentName(context,WatchJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(6L*60*60*1000)
                .setPersisted(true)
                .build();
        scheduler.schedule(job);
    }

    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try {
                JSONArray watches=Store.all(this);
                long now=System.currentTimeMillis();
                for(int i=0;i<watches.length();i++) {
                    JSONObject w=watches.optJSONObject(i);
                    if(w==null || !w.optBoolean("active",true)) continue;
                    long interval=Math.max(6,w.optInt("frequency",24))*3600000L;
                    if(now-w.optLong("lastChecked",0)>=interval) {
                        try { SearchEngine.scan(this,w.optInt("id")); }
                        catch(Exception ignored) { /* fallo transitorio: volver a probar en la siguiente ejecución */ }
                    }
                }
            } finally { jobFinished(params,false); }
        },"Cazador-Background").start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) { return true; }
}
