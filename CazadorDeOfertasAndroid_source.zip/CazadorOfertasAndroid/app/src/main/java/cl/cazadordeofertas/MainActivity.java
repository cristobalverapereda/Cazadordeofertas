package cl.cazadordeofertas;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.View;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private volatile boolean busy=false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10,16,29));
        getWindow().setNavigationBarColor(Color.rgb(10,16,29));
        getWindow().getDecorView().setSystemUiVisibility(0);
        Store.seed(this);
        web=new WebView(this);
        web.setBackgroundColor(Color.rgb(10,16,29));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.addJavascriptInterface(new Bridge(),"Android");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u=req.getUrl();
                if("file".equals(u.getScheme()) && "android_asset".equals(u.getHost())) return false;
                openExternal(u.toString()); return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        WatchJobService.schedule(this);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},300);
    }

    private void openExternal(String link) {
        try {
            Uri uri=Uri.parse(link);
            String s=uri.getScheme();
            if(!"https".equals(s) && !"http".equals(s)) return;
            startActivity(new Intent(Intent.ACTION_VIEW,uri));
        } catch(Exception ignored) {}
    }

    private void push(String function,String jsonString) {
        runOnUiThread(() -> { if(web!=null) web.evaluateJavascript("window."+function+"("+JSONObject.quote(jsonString)+")",null); });
    }

    private class Bridge {
        @JavascriptInterface public String getState() { return Store.state(MainActivity.this).toString(); }
        @JavascriptInterface public void saveWatch(String value) {
            try { Store.save(MainActivity.this,new JSONObject(value)); push("onUpdated", "Guardado"); }
            catch(Exception e) { push("onError",e.getMessage()); }
        }
        @JavascriptInterface public void deleteWatch(int id) { Store.delete(MainActivity.this,id); push("onUpdated","Encargo eliminado"); }
        @JavascriptInterface public void saveKey(String value) {
            Store.apiKey(MainActivity.this,value); WatchJobService.schedule(MainActivity.this);
            push("onUpdated","Clave guardada en el teléfono");
        }
        @JavascriptInterface public void openProduct(String url) { runOnUiThread(() -> openExternal(url)); }
        @JavascriptInterface public void scanWatch(int id) {
            if(busy) { push("onError","Ya hay una búsqueda en curso"); return; }
            busy=true;
            new Thread(() -> {
                try { JSONObject res=SearchEngine.scan(MainActivity.this,id); push("onScanFinished",res.toString()); }
                catch(Exception e) { push("onError",e.getMessage()==null?"Error de conexión":e.getMessage()); }
                finally { busy=false; }
            },"Cazador-Manual").start();
        }
    }

    @Override protected void onDestroy() {
        if(web!=null) { web.removeJavascriptInterface("Android"); web.destroy(); web=null; }
        super.onDestroy();
    }
}
